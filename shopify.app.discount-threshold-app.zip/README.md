# Shopify App Template - Remix

This is a template for building a [Shopify app](https://shopify.dev/docs/apps/getting-started) using the [Remix](https://remix.run) framework.

Rather than cloning this repo, you can use your preferred package manager and the Shopify CLI with [these steps](https://shopify.dev/docs/apps/getting-started/create).

Visit the [`shopify.dev` documentation](https://shopify.dev/docs/api/shopify-app-remix) for more details on the Remix app package.

## Quick start

### Prerequisites

Before you begin, you'll need the following:

1. **Node.js**: [Download and install](https://nodejs.org/en/download/) it if you haven't already.
2. **Shopify Partner Account**: [Create an account](https://partners.shopify.com/signup) if you don't have one.
3. **Test Store**: Set up either a [development store](https://help.shopify.com/en/partners/dashboard/development-stores#create-a-development-store) or a [Shopify Plus sandbox store](https://help.shopify.com/en/partners/dashboard/managing-stores/plus-sandbox-store) for testing your app.

### Setup

If you used the CLI to create the template, you can skip this section.

Using yarn:

```shell
yarn install
```

Using npm:

```shell
npm install
```

Using pnpm:

```shell
pnpm install
```

### Local Development

Using yarn:

```shell
yarn dev
```

Using npm:

```shell
npm run dev
```

Using pnpm:

```shell
pnpm run dev
```

Press P to open the URL to your app. Once you click install, you can start development.

Local development is powered by [the Shopify CLI](https://shopify.dev/docs/apps/tools/cli). It logs into your partners account, connects to an app, provides environment variables, updates remote config, creates a tunnel and provides commands to generate extensions.

### Authenticating and querying data

To authenticate and query data you can use the `shopify` const that is exported from `/app/shopify.server.js`:

```js
export async function loader({ request }) {
  const { admin } = await shopify.authenticate.admin(request);

  const response = await admin.graphql(`
    {
      products(first: 25) {
        nodes {
          title
          description
        }
      }
    }`);

  const {
    data: {
      products: { nodes },
    },
  } = await response.json();

  return nodes;
}
```

This template comes preconfigured with examples of:

1. Setting up your Shopify app in [/app/shopify.server.ts](https://github.com/Shopify/shopify-app-template-remix/blob/main/app/shopify.server.ts)
2. Querying data using Graphql. Please see: [/app/routes/app.\_index.tsx](https://github.com/Shopify/shopify-app-template-remix/blob/main/app/routes/app._index.tsx).
3. Responding to webhooks in individual files such as [/app/routes/webhooks.app.uninstalled.tsx](https://github.com/Shopify/shopify-app-template-remix/blob/main/app/routes/webhooks.app.uninstalled.tsx) and [/app/routes/webhooks.app.scopes_update.tsx](https://github.com/Shopify/shopify-app-template-remix/blob/main/app/routes/webhooks.app.scopes_update.tsx)

Please read the [documentation for @shopify/shopify-app-remix](https://www.npmjs.com/package/@shopify/shopify-app-remix#authenticating-admin-requests) to understand what other API's are available.

## Deployment

### Application Storage

This template uses [Prisma](https://www.prisma.io/) to store session data, by default using an [SQLite](https://www.sqlite.org/index.html) database.
The database is defined as a Prisma schema in `prisma/schema.prisma`.

This use of SQLite works in production if your app runs as a single instance.
The database that works best for you depends on the data your app needs and how it is queried.
You can run your database of choice on a server yourself or host it with a SaaS company.
Here's a short list of databases providers that provide a free tier to get started:

| Database   | Type             | Hosters                                                                                                                                                                                                                               |
| ---------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| MySQL      | SQL              | [Digital Ocean](https://www.digitalocean.com/products/managed-databases-mysql), [Planet Scale](https://planetscale.com/), [Amazon Aurora](https://aws.amazon.com/rds/aurora/), [Google Cloud SQL](https://cloud.google.com/sql/docs/mysql) |
| PostgreSQL | SQL              | [Digital Ocean](https://www.digitalocean.com/products/managed-databases-postgresql), [Amazon Aurora](https://aws.amazon.com/rds/aurora/), [Google Cloud SQL](https://cloud.google.com/sql/docs/postgres)                                   |
| Redis      | Key-value        | [Digital Ocean](https://www.digitalocean.com/products/managed-databases-redis), [Amazon MemoryDB](https://aws.amazon.com/memorydb/)                                                                                                        |
| MongoDB    | NoSQL / Document | [Digital Ocean](https://www.digitalocean.com/products/managed-databases-mongodb), [MongoDB Atlas](https://www.mongodb.com/atlas/database)                                                                                                  |

To use one of these, you can use a different [datasource provider](https://www.prisma.io/docs/reference/api-reference/prisma-schema-reference#datasource) in your `schema.prisma` file, or a different [SessionStorage adapter package](https://github.com/Shopify/shopify-api-js/blob/main/packages/shopify-api/docs/guides/session-storage.md).

### Build

Remix handles building the app for you, by running the command below with the package manager of your choice:

Using yarn:

```shell
yarn build
```

Using npm:

```shell
npm run build
```

Using pnpm:

```shell
pnpm run build
```

## Hosting

When you're ready to set up your app in production, you can follow [our deployment documentation](https://shopify.dev/docs/apps/deployment/web) to host your app on a cloud provider like [Heroku](https://www.heroku.com/) or [Fly.io](https://fly.io/).

When you reach the step for [setting up environment variables](https://shopify.dev/docs/apps/deployment/web#set-env-vars), you also need to set the variable `NODE_ENV=production`.

### Hosting on Vercel

Using the Vercel Preset is recommended when hosting your Shopify Remix app on Vercel. You'll also want to ensure imports that would normally come from `@remix-run/node` are imported from `@vercel/remix` instead. Learn more about hosting Remix apps on Vercel [here](https://vercel.com/docs/frameworks/remix).

```diff
// vite.config.ts
import { vitePlugin as remix } from "@remix-run/dev";
import { defineConfig, type UserConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";
+ import { vercelPreset } from '@vercel/remix/vite';

installGlobals();

export default defineConfig({
  plugins: [
    remix({
      ignoredRouteFiles: ["**/.*"],
+     presets: [vercelPreset()],
    }),
    tsconfigPaths(),
  ],
});
```

## Troubleshooting

### Database tables don't exist

If you get this error:

```
The table `main.Session` does not exist in the current database.
```

You need to create the database for Prisma. Run the `setup` script in `package.json` using your preferred package manager.

### Navigating/redirecting breaks an embedded app

Embedded Shopify apps must maintain the user session, which can be tricky inside an iFrame. To avoid issues:

1. Use `Link` from `@remix-run/react` or `@shopify/polaris`. Do not use `<a>`.
2. Use the `redirect` helper returned from `authenticate.admin`. Do not use `redirect` from `@remix-run/node`
3. Use `useSubmit` or `<Form/>` from `@remix-run/react`. Do not use a lowercase `<form/>`.

This only applies if your app is embedded, which it will be by default.

### Non Embedded

Shopify apps are best when they are embedded in the Shopify Admin, which is how this template is configured. If you have a reason to not embed your app please make the following changes:

1. Ensure `embedded = false` is set in [shopify.app.toml`](./shopify.app.toml). [Docs here](https://shopify.dev/docs/apps/build/cli-for-apps/app-configuration#global).
2. Pass `isEmbeddedApp: false` to `shopifyApp()` in `./app/shopify.server.js|ts`.
3. Change the `isEmbeddedApp` prop to `isEmbeddedApp={false}` for the `AppProvider` in `/app/routes/app.jsx|tsx`.
4. Remove the `@shopify/app-bridge-react` dependency from [package.json](./package.json) and `vite.config.ts|js`.
5. Remove anything imported from `@shopify/app-bridge-react`.  For example: `NavMenu`, `TitleBar` and `useAppBridge`.

### OAuth goes into a loop when I change my app's scopes

If you change your app's scopes and authentication goes into a loop and fails with a message from Shopify that it tried too many times, you might have forgotten to update your scopes with Shopify.
To do that, you can run the `deploy` CLI command.

Using yarn:

```shell
yarn deploy
```

Using npm:

```shell
npm run deploy
```

Using pnpm:

```shell
pnpm run deploy
```

### My shop-specific webhook subscriptions aren't updated

If you are registering webhooks in the `afterAuth` hook, using `shopify.registerWebhooks`, you may find that your subscriptions aren't being updated.  

Instead of using the `afterAuth` hook, the recommended approach is to declare app-specific webhooks in the `shopify.app.toml` file.  This approach is easier since Shopify will automatically update changes to webhook subscriptions every time you run `deploy` (e.g: `npm run deploy`).  Please read these guides to understand more:

1. [app-specific vs shop-specific webhooks](https://shopify.dev/docs/apps/build/webhooks/subscribe#app-specific-subscriptions)
2. [Create a subscription tutorial](https://shopify.dev/docs/apps/build/webhooks/subscribe/get-started?framework=remix&deliveryMethod=https)

If you do need shop-specific webhooks, please keep in mind that the package calls `afterAuth` in 2 scenarios:

- After installing the app
- When an access token expires

During normal development, the app won't need to re-authenticate most of the time, so shop-specific subscriptions aren't updated. To force your app to update the subscriptions, you can uninstall and reinstall it in your development store. That will force the OAuth process and call the `afterAuth` hook.

### Admin created webhook failing HMAC validation

Webhooks subscriptions created in the [Shopify admin](https://help.shopify.com/en/manual/orders/notifications/webhooks) will fail HMAC validation. This is because the webhook payload is not signed with your app's secret key.  There are 2 solutions:

1. Use [app-specific webhooks](https://shopify.dev/docs/apps/build/webhooks/subscribe#app-specific-subscriptions) defined in your toml file instead (recommended)
2. Create [webhook subscriptions](https://shopify.dev/docs/api/shopify-app-remix/v1/guide-webhooks) using the `shopifyApp` object.

Test your webhooks with the [Shopify CLI](https://shopify.dev/docs/apps/tools/cli/commands#webhook-trigger) or by triggering events manually in the Shopify admin(e.g. Updating the product title to trigger a `PRODUCTS_UPDATE`).

### Incorrect GraphQL Hints

By default the [graphql.vscode-graphql](https://marketplace.visualstudio.com/items?itemName=GraphQL.vscode-graphql) extension for VS Code will assume that GraphQL queries or mutations are for the [Shopify Admin API](https://shopify.dev/docs/api/admin). This is a sensible default, but it may not be true if:

1. You use another Shopify API such as the storefront API.
2. You use a third party GraphQL API.

in this situation, please update the [.graphqlrc.ts](https://github.com/Shopify/shopify-app-template-remix/blob/main/.graphqlrc.ts) config.

### First parameter has member 'readable' that is not a ReadableStream.

See [hosting on Vercel](#hosting-on-vercel).

### Admin object undefined on webhook events triggered by the CLI

When you trigger a webhook event using the Shopify CLI, the `admin` object will be `undefined`. This is because the CLI triggers an event with a valid, but non-existent, shop. The `admin` object is only available when the webhook is triggered by a shop that has installed the app.

Webhooks triggered by the CLI are intended for initial experimentation testing of your webhook configuration. For more information on how to test your webhooks, see the [Shopify CLI documentation](https://shopify.dev/docs/apps/tools/cli/commands#webhook-trigger).

### Using Defer & await for streaming responses

To test [streaming using defer/await](https://remix.run/docs/en/main/guides/streaming) during local development you'll need to use the Shopify CLI slightly differently:

1. First setup ngrok: https://ngrok.com/product/secure-tunnels
2. Create an ngrok tunnel on port 8080: `ngrok http 8080`.
3. Copy the forwarding address. This should be something like: `https://f355-2607-fea8-bb5c-8700-7972-d2b5-3f2b-94ab.ngrok-free.app`
4. In a separate terminal run `yarn shopify app dev --tunnel-url=TUNNEL_URL:8080` replacing `TUNNEL_URL` for the address you copied in step 3.

By default the CLI uses a cloudflare tunnel. Unfortunately it cloudflare tunnels wait for the Response stream to finish, then sends one chunk.

This will not affect production, since tunnels are only for local development.

### Using MongoDB and Prisma

By default this template uses SQLlite as the database. It is recommended to move to a persisted database for production. If you choose to use MongoDB, you will need to make some modifications to the schema and prisma configuration. For more information please see the [Prisma MongoDB documentation](https://www.prisma.io/docs/orm/overview/databases/mongodb).

Alternatively you can use a MongDB database directly with the [MongoDB session storage adapter](https://github.com/Shopify/shopify-app-js/tree/main/packages/apps/session-storage/shopify-app-session-storage-mongodb).

#### Mapping the id field

In MongoDB, an ID must be a single field that defines an @id attribute and a @map("\_id") attribute.
The prisma adapter expects the ID field to be the ID of the session, and not the \_id field of the document.

To make this work you can add a new field to the schema that maps the \_id field to the id field. For more information see the [Prisma documentation](https://www.prisma.io/docs/orm/prisma-schema/data-model/models#defining-an-id-field)

```prisma
model Session {
  session_id  String    @id @default(auto()) @map("_id") @db.ObjectId
  id          String    @unique
...
}
```

#### Error: The "mongodb" provider is not supported with this command

MongoDB does not support the [prisma migrate](https://www.prisma.io/docs/orm/prisma-migrate/understanding-prisma-migrate/overview) command. Instead, you can use the [prisma db push](https://www.prisma.io/docs/orm/reference/prisma-cli-reference#db-push) command and update the `shopify.web.toml` file with the following commands. If you are using MongoDB please see the [Prisma documentation](https://www.prisma.io/docs/orm/overview/databases/mongodb) for more information.

```toml
[commands]
predev = "npx prisma generate && npx prisma db push"
dev = "npm exec remix vite:dev"
```

#### Prisma needs to perform transactions, which requires your mongodb server to be run as a replica set

See the [Prisma documentation](https://www.prisma.io/docs/getting-started/setup-prisma/start-from-scratch/mongodb/connect-your-database-node-mongodb) for connecting to a MongoDB database.

### I want to use Polaris v13.0.0 or higher

Currently, this template is set up to work on node v18.20 or higher. However, `@shopify/polaris` is limited to v12 because v13 can only run on node v20+.

You don't have to make any changes to the code in order to be able to upgrade Polaris to v13, but you'll need to do the following:

- Upgrade your node version to v20.10 or higher.
- Update your `Dockerfile` to pull `FROM node:20-alpine` instead of `node:18-alpine`

### "nbf" claim timestamp check failed

This error will occur of the `nbf` claim timestamp check failed. This is because the JWT token is expired.
If you  are consistently getting this error, it could be that the clock on your machine is not in sync with the server.

To fix this ensure you have enabled `Set time and date automatically` in the `Date and Time` settings on your computer.

## Benefits

Shopify apps are built on a variety of Shopify tools to create a great merchant experience.

<!-- TODO: Uncomment this after we've updated the docs -->
<!-- The [create an app](https://shopify.dev/docs/apps/getting-started/create) tutorial in our developer documentation will guide you through creating a Shopify app using this template. -->

The Remix app template comes with the following out-of-the-box functionality:

- [OAuth](https://github.com/Shopify/shopify-app-js/tree/main/packages/shopify-app-remix#authenticating-admin-requests): Installing the app and granting permissions
- [GraphQL Admin API](https://github.com/Shopify/shopify-app-js/tree/main/packages/shopify-app-remix#using-the-shopify-admin-graphql-api): Querying or mutating Shopify admin data
- [Webhooks](https://github.com/Shopify/shopify-app-js/tree/main/packages/shopify-app-remix#authenticating-webhook-requests): Callbacks sent by Shopify when certain events occur
- [AppBridge](https://shopify.dev/docs/api/app-bridge): This template uses the next generation of the Shopify App Bridge library which works in unison with previous versions.
- [Polaris](https://polaris.shopify.com/): Design system that enables apps to create Shopify-like experiences

## Tech Stack

This template uses [Remix](https://remix.run). The following Shopify tools are also included to ease app development:

- [Shopify App Remix](https://shopify.dev/docs/api/shopify-app-remix) provides authentication and methods for interacting with Shopify APIs.
- [Shopify App Bridge](https://shopify.dev/docs/apps/tools/app-bridge) allows your app to seamlessly integrate your app within Shopify's Admin.
- [Polaris React](https://polaris.shopify.com/) is a powerful design system and component library that helps developers build high quality, consistent experiences for Shopify merchants.
- [Webhooks](https://github.com/Shopify/shopify-app-js/tree/main/packages/shopify-app-remix#authenticating-webhook-requests): Callbacks sent by Shopify when certain events occur
- [Polaris](https://polaris.shopify.com/): Design system that enables apps to create Shopify-like experiences

## Resources

- [Remix Docs](https://remix.run/docs/en/v1)
- [Shopify App Remix](https://shopify.dev/docs/api/shopify-app-remix)
- [Introduction to Shopify apps](https://shopify.dev/docs/apps/getting-started)
- [App authentication](https://shopify.dev/docs/apps/auth)
- [Shopify CLI](https://shopify.dev/docs/apps/tools/cli)
- [App extensions](https://shopify.dev/docs/apps/app-extensions/list)
- [Shopify Functions](https://shopify.dev/docs/api/functions)
- [Getting started with internationalizing your app](https://shopify.dev/docs/apps/best-practices/internationalization/getting-started)





-----------------------------------------------------------------------------------------------------------------------------------------

// constants/billingTypes.js
export const BILLING_TYPES = {
  PAY_AS_YOU_GO: 'PAY_AS_YOU_GO',
  PREPAID_ONE_TIME: 'PREPAID_ONE_TIME', 
  PREPAID_AUTO_RENEW: 'PREPAID_AUTO_RENEW',
  PREPAID_SEPARATE_ORDERS: 'PREPAID_SEPARATE_ORDERS'
};

export const BILLING_TYPE_LABELS = {
  [BILLING_TYPES.PAY_AS_YOU_GO]: 'Pay As You Go (Auto-renew)',
  [BILLING_TYPES.PREPAID_ONE_TIME]: 'Prepaid One-Time',
  [BILLING_TYPES.PREPAID_AUTO_RENEW]: 'Prepaid Auto-renew',
  [BILLING_TYPES.PREPAID_SEPARATE_ORDERS]: 'Prepaid (Separate Orders)'
};

// constants/frequency.js
export const FREQUENCY_UNITS = {
  DAYS: 'DAYS',
  WEEKS: 'WEEKS', 
  MONTHS: 'MONTHS',
  YEARS: 'YEARS'
};

export const FREQUENCY_UNIT_LABELS = {
  [FREQUENCY_UNITS.DAYS]: 'Days',
  [FREQUENCY_UNITS.WEEKS]: 'Weeks',
  [FREQUENCY_UNITS.MONTHS]: 'Months',
  [FREQUENCY_UNITS.YEARS]: 'Years'
};

const recurringDayOptions = [
  { value: "SAME_AS_INITIAL", label: "Same day as initial order" },
  { value: "1", label: "1st of each month" },
  { value: "2", label: "2nd of each month" },
  { value: "3", label: "3rd of each month" },
  // ... continue up to 31
  { value: "31", label: "31st of each month" }
];

const simpleDiscount = {
  discountEnabled: true,
  discountType: "PERCENT_OFF",
  discountValue: 20,
  changeDiscountAfterPayments: false
};

// Example 2: 50% off first 3 payments, then 10% off
const tieredDiscount = {
  discountEnabled: true,
  discountType: "PERCENT_OFF", 
  discountValue: 50,
  changeDiscountAfterPayments: true,
  changeDiscountAfterCycles: 3,
  newDiscountType: "PERCENT_OFF",
  newDiscountValue: 10
};

// Example 3: $10 off first payment, then $5 off
const amountDiscount = {
  discountEnabled: true,
  discountType: "AMOUNT_OFF",
  discountValue: 10,
  changeDiscountAfterPayments: true, 
  changeDiscountAfterCycles: 1,
  newDiscountType: "AMOUNT_OFF",
  newDiscountValue: 5
};

// Example 1: Basic subscription
const basicPlan = {
  inventoryPolicy: "ON_SALE",
  cancellationPolicy: "AFTER_INITIAL_ONLY", 
  automaticExpiration: "UNLIMITED"
};

// Example 2: Limited-time subscription  
const limitedPlan = {
  inventoryPolicy: "ON_FULFILLMENT",
  cancellationPolicy: "AFTER_INITIAL_PLUS_3", // Can cancel after 4 total orders
  automaticExpiration: "6_ORDERS_TOTAL" // Ends after 6 orders
};

// Example 3: Trial subscription
const trialPlan = {
  inventoryPolicy: "ON_SALE",
  cancellationPolicy: "AFTER_INITIAL_ONLY",
  automaticExpiration: "1_ORDER_ONLY" // One-time trial
};



VALUES
-- ORDER FREQUENCY
  (uuid(), 'abc', 'en', 'ORDER_FREQUENCY', 'ORDER_FREQUENCY_TEXT', 'Order frequency', 'Order frequency', 1),
  (uuid(), 'abc', 'en', 'ORDER_FREQUENCY', 'DELIVERY_INTERVAL_TEXT', 'Delivery Interval', 'Delivery Interval', 2),
  (uuid(), 'abc', 'en', 'ORDER_FREQUENCY', 'EDIT_FREQUENCY_BTN_TEXT', 'Edit Frequency', 'Edit Frequency', 3),
  (uuid(), 'abc', 'en', 'ORDER_FREQUENCY', 'UPDATE_FREQUENCY_BTN_TEXT', 'Update', 'Update', 4),
  (uuid(), 'abc', 'en', 'ORDER_FREQUENCY', 'NO_DELIVERY_FREQUENCY_FOUND_TEXT', 'No frequency available to change.', 'No frequency available to change.', 5),

-- PRODUCT MANAGEMENT
  (uuid(), 'abc', 'en', 'PRODUCT_MANAGEMENT', 'PRODUCT_ACCORDION_TEXT', 'Product in this Subscription', 'Product in this Subscription', 1),
  (uuid(), 'abc', 'en', 'PRODUCT_MANAGEMENT', 'PRODUCTS_LABEL_TEXT', 'Products', 'Products', 2),
  (uuid(), 'abc', 'en', 'PRODUCT_MANAGEMENT', 'SELECT_PRODUCT_LABEL_TEXT', 'Select Product', 'Select Product', 3),

-- SKIP & QUEUE
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'SKIP_BADGE_TEXT', 'Skipped', 'Skipped', 1),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'QUEUE_BADGE_TEXT', 'Queued', 'Queued', 2),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'SKIP_ORDER_BUTTON_TEXT', 'Skip Order', 'Skip Order', 3),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'UPCOMING_SKIP_ALERT_TEXT', 'Are you sure you want to skip the next order? Next order date will be changed to {{next_order_date}}.', 'Are you sure you want to skip the next order? Next order date will be changed to {{next_order_date}}.', 4),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'CONFIRM_SKIP_ORDER_TEXT', 'Confirm Skip Order', 'Confirm Skip Order', 5),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'SKIP_FOR_UPCOMING_ORDER_TEXT', 'Skipped for upcoming order', 'Skipped for upcoming order', 6),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'UNSKIP_ORDER_BUTTON_TEXT', 'Unskip Order', 'Unskip Order', 7),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'UNSKIP_ORDER_UPDATE_BUTTON_TEXT', 'Unskip', 'Unskip', 8),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'UNSKIP_ORDER_MODAL_TITLE_TEXT', 'Unskip Order', 'Unskip Order', 9),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'UNSKIP_ORDER_MESSAGE_TEXT', 'Are you sure you want to unskip this order?', 'Are you sure you want to unskip this order?', 10),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'SKIP_FULFILLMENT_BUTTON_TEXT', 'Skip Fulfillment', 'Skip Fulfillment', 11),
  (uuid(), 'abc', 'en', 'SKIP_QUEUE', 'CONFIRM_SKIP_FULFILLMENT_BUTTON_TEXT', 'Are you sure you want to skip this order?', 'Are you sure you want to skip this order?', 12),

-- DELETE CONFIRMATION
  (uuid(), 'abc', 'en', 'DELETE_CONFIRMATION', 'DELETE_CONFIRMATION_MESSAGE_TEXT', 'Are you sure?', 'Are you sure?', 1),
  (uuid(), 'abc', 'en', 'DELETE_CONFIRMATION', 'DELETE_MESSAGE_TEXT', 'You are about to delete this product.', 'You are about to delete this product.', 2),
  (uuid(), 'abc', 'en', 'DELETE_CONFIRMATION', 'YES_BUTTON_TEXT', 'Yes', 'Yes', 3),
  (uuid(), 'abc', 'en', 'DELETE_CONFIRMATION', 'NO_BUTTON_TEXT', 'No', 'No', 4),
  (uuid(), 'abc', 'en', 'DELETE_CONFIRMATION', 'DELETE_BUTTON_TEXT', 'Delete', 'Delete', 5),

-- PAUSE & RESUME
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'PAUSE_SUBSCRIPTION_TEXT', 'Pause Subscription', 'Pause Subscription', 1),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'RESUME_SUBSCRIPTION_TEXT', 'Resume Subscription', 'Resume Subscription', 2),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'PAUSE_BADGE_TEXT', 'PAUSED', 'PAUSED', 3),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'CONFIRM_RESUME_TEXT', 'Are you sure you want to resume the subscription?', 'Are you sure you want to resume the subscription?', 4),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'CONFIRM_PAUSE_TEXT', 'Are you sure you want to pause the subscription?', 'Are you sure you want to pause the subscription?', 5),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'ARCHIVED_LABEL_TEXT', 'Archived', 'Archived', 6),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'CANCELED_LABEL_TEXT', 'Canceled', 'Canceled', 7),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'PAUSE_ORDER_CYCLE_TEXT', 'How many orders/cycles you want subscription to pause for?', 'How many orders/cycles you want subscription to pause for?', 8),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'PAUSE_FEEDBACK_TEXT', 'Pause Feedback', 'Pause Feedback', 9),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'PAUSE_TILL_DATE_TEXT', 'Pause Till Date', 'Pause Till Date', 10),
  (uuid(), 'abc', 'en', 'PAUSE_RESUME', 'SELECTED_PAUSE_REASON_TEXT', 'Selected Pause Reason', 'Selected Pause Reason', 11),

-- CANCELLATION
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCEL_PREPAID_CONFIRM_TEXT', 'Are you sure you want to cancel your prepaid subscription?', 'Are you sure you want to cancel your prepaid subscription?', 1),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCEL_PAYG_CONFIRM_TEXT', 'Are you sure you want to cancel your subscription?', 'Are you sure you want to cancel your subscription?', 2),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCEL_PREPAID_BUTTON_TEXT', 'Cancel Prepaid Subscription', 'Cancel Prepaid Subscription', 3),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCEL_PAYG_BUTTON_TEXT', 'Cancel Subscription', 'Cancel Subscription', 4),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCEL_ACCORDION_TITLE', 'Cancel Subscription', 'Cancel Subscription', 5),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'SELECT_CANCELLATION_REASON_LABEL', 'Select Cancellation Reason', 'Select Cancellation Reason', 6),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'SELECT_CANCELLATION_REASON_PLACEHOLDER', 'Select Cancellation Reason', 'Select Cancellation Reason', 7),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCELLATION_FEEDBACK_LABEL', 'Cancellation Reason', 'Cancellation Reason', 8),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCELLATION_DATE_TITLE_TEXT', 'Cancellation Date', 'Cancellation Date', 9),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCELLATION_OPTIONAL_HINT_TEXT', '(optional)', '(optional)', 10),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCELLATION_REASON_REQUIRED_MSG', 'Please select a reason for cancellation.', 'Please select a reason for cancellation.', 11),
  (uuid(), 'abc', 'en', 'CANCELLATION', 'CANCELLATION_DISCOUNT_ALREADY_USED_MSG', 'Discount for cancellation already used.', 'Discount for cancellation already used.', 12),

-- FREEZE
  (uuid(), 'abc', 'en', 'FREEZE', 'FREEZE_UPDATE_MESSAGE', 'Subscription cannot be modified until {{minCycles}} orders have completed.', 'Subscription cannot be modified until {{minCycles}} orders have completed.', 1),
  (uuid(), 'abc', 'en', 'FREEZE', 'CONTRACT_FROZEN_MESSAGE', 'Your subscription contract is frozen by your shop owner.', 'Your subscription contract is frozen by your shop owner.', 2),
  (uuid(), 'abc', 'en', 'FREEZE', 'PREVENT_BEFORE_DAYS_MESSAGE', 'You can not cancel/pause the subscription before {{preventDays}} days from your next order date.', 'You can not cancel/pause the subscription before {{preventDays}} days from your next order date.', 3),

-- CYCLE MANAGEMENT
  (uuid(), 'abc', 'en', 'CYCLE_MGMT', 'MIN_CYCLE_TEXT', 'Min Cycle', 'Min Cycle', 1),
  (uuid(), 'abc', 'en', 'CYCLE_MGMT', 'MAX_CYCLE_TEXT', 'Max Cycle', 'Max Cycle', 2),
  (uuid(), 'abc', 'en', 'CYCLE_MGMT', 'EDIT_DELIVERY_INTERVAL_TEXT', 'Edit Delivery Interval', 'Edit Delivery Interval', 3),
  (uuid(), 'abc', 'en', 'CYCLE_MGMT', 'DELIVERY_FREQUENCY_TEXT', 'Delivery Frequency', 'Delivery Frequency', 4),
  (uuid(), 'abc', 'en', 'CYCLE_MGMT', 'CURRENT_BILLING_CYCLE_TEXT', 'Current billing cycle:', 'Current billing cycle:', 5),

-- BANNERS
  (uuid(), 'abc', 'en', 'BANNERS', 'SECURITY_CHALLENGE_BANNER_TEXT', 'Security Challenge Banner', 'Security Challenge Banner', 1);

