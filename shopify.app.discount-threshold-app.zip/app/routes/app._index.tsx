import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, useActionData, useSubmit, useNavigation, Form } from "@remix-run/react";
import { useState, useCallback, useEffect } from "react";
import {
  Page, Layout, Card, Button, Badge, Text, BlockStack,
  InlineStack, EmptyState, Modal, Toast, Frame, FormLayout, TextField,
  Banner, Divider, Select, DatePicker, Popover, Box, Icon, InlineGrid, Tooltip,
  IndexTable, useIndexResourceState, IndexFilters, useSetIndexFiltersMode, Link, Pagination, FooterHelp
} from "@shopify/polaris";
import { CalendarIcon, ClipboardIcon, CheckIcon } from "@shopify/polaris-icons";
import { ReminderType } from "@prisma/client";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";

const DISCOUNT_CATEGORIES = [
  "Sales Discount",
  "SPIFF Program Discount",
  "Special Product Discount",
  "In Store Demo Discount",
  "Education, Music and Religious Discount",
  "Staff Discount",
  "Artist Program",
  "Marketing Giveaways",
  "RMA",
  "Non Warranty Service",
  "Other Service Expense",
  "Product Development",
];

// After activating a discount that has a future startDate, Shopify sets it to ACTIVE.
// We must re-apply the original startsAt so Shopify re-classifies it as SCHEDULED.
async function restoreStartsAtIfFuture(admin: any, discountGid: string, startDate: Date | null) {
  if (!startDate) return;
  const now = new Date();
  if (startDate <= now) return; // already past — no action needed
  await admin.graphql(
    `mutation discountCodeAppUpdate($id: ID!, $discount: DiscountCodeAppInput!) {
      discountCodeAppUpdate(id: $id, codeAppDiscount: $discount) {
        userErrors { field message }
      }
    }`,
    { variables: { id: discountGid, discount: { startsAt: startDate.toISOString() } } }
  ).catch((e: any) => console.error("Failed to restore startsAt:", e));
}

async function deletePaymentTypeMetafield(admin: any, discountGid: string) {
  try {
    console.log("deletePaymentTypeMetafield starting for GID:", discountGid);
    const query = `
      query getMetafieldId($id: ID!) {
        discountNode(id: $id) {
          metafield(namespace: "$app", key: "payment_type") {
            id
          }
        }
      }
    `;
    const res = await admin.graphql(query, { variables: { id: discountGid } });
    const data = await res.json() as any;
    console.log("deletePaymentTypeMetafield query result:", JSON.stringify(data, null, 2));
    const metafieldId = data?.data?.discountNode?.metafield?.id;
    if (metafieldId) {
      console.log("Found metafieldId:", metafieldId, "deleting...");
      const mutation = `
        mutation metafieldDelete($input: MetafieldDeleteInput!) {
          metafieldDelete(input: $input) {
            deletedId
            userErrors {
              field
              message
            }
          }
        }
      `;
      const deleteRes = await admin.graphql(mutation, { variables: { input: { id: metafieldId } } });
      const deleteData = await deleteRes.json() as any;
      console.log("deletePaymentTypeMetafield mutation result:", JSON.stringify(deleteData, null, 2));
    } else {
      console.log("No payment_type metafield found to delete.");
    }
  } catch (e) {
    console.error("Error deleting payment_type metafield:", e);
  }
}


const CREATE_DISCOUNT_MUTATION = `
  mutation discountCodeAppCreate($discount: DiscountCodeAppInput!) {
    discountCodeAppCreate(codeAppDiscount: $discount) {
      codeAppDiscount {
        discountId
      }
      userErrors {
        field
        message
      }
    }
  }
`;

const UPDATE_DISCOUNT_MUTATION = `
  mutation discountCodeAppUpdate($id: ID!, $discount: DiscountCodeAppInput!) {
    discountCodeAppUpdate(id: $id, codeAppDiscount: $discount) {
      userErrors {
        field
        message
      }
    }
  }
`;

const SET_METAFIELD_MUTATION = `
  mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
    metafieldsSet(metafields: $metafields) {
      userErrors { field message }
    }
  }
`;

const GET_FUNCTIONS_QUERY = `
  query {
    shopifyFunctions(first: 25) {
      nodes {
        id
        title
        apiType
      }
    }
  }
`;

const SHOP_INFO_QUERY = `
  query {
    shop {
      currencyCode
    }
  }
`;

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session, admin } = await authenticate.admin(request);
  const discounts = await prisma.discountThreshold.findMany({
    where: { shop: session.shop },
    orderBy: { createdAt: "desc" },
  });

  // Fetch shop currency
  let currencyCode = "INR";
  try {
    const shopRes = await admin.graphql(SHOP_INFO_QUERY);
    const shopData = await shopRes.json() as any;
    currencyCode = shopData?.data?.shop?.currencyCode || "INR";
  } catch { }

  // Batch-fetch asyncUsageCount and status for each discount via aliased GraphQL (codeDiscountNode)
  const usageCounts: Record<string, number> = {};
  const discountStatuses: Record<string, string> = {};
  if (discounts.length > 0) {
    try {
      const aliases = discounts
        .map((d, i) => `d${i}: codeDiscountNode(id: "${d.discountGid}") { codeDiscount { ... on DiscountCodeApp { asyncUsageCount status } } }`)
        .join("\n      ");
      const batchQuery = `query { ${aliases} }`;
      const usageRes = await admin.graphql(batchQuery);
      const usageData = await usageRes.json() as any;
      discounts.forEach((d, i) => {
        usageCounts[d.id] = usageData?.data?.[`d${i}`]?.codeDiscount?.asyncUsageCount ?? 0;
        discountStatuses[d.id] = usageData?.data?.[`d${i}`]?.codeDiscount?.status ?? "";
      });
    } catch { }
  }

  return json({ discounts, currencyCode, usageCounts, discountStatuses });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { session, admin } = await authenticate.admin(request);
  const shop = session.shop;
  const formData = await request.formData();
  const intent = formData.get("intent") as string;
  const id = formData.get("id") as string;

  if (intent === "delete") {
    const discount = await prisma.discountThreshold.findUnique({ where: { id } });
    if (!discount || discount.shop !== shop) {
      return json({ success: false, actionType: "delete", errors: { general: "Discount not found" } });
    }
    try {
      await admin.graphql(
        `mutation discountCodeDelete($id: ID!) { discountCodeDelete(id: $id) { deletedCodeDiscountId userErrors { field message } } }`,
        { variables: { id: discount.discountGid } }
      );
    } catch (e) {
      console.error("GraphQL delete failed:", e);
    }
    await prisma.discountThreshold.delete({ where: { id } });
    return json({ success: true, actionType: "delete" });
  }

  if (intent === "activatePaymentCustomization") {
    try {
      const response = await admin.graphql(GET_FUNCTIONS_QUERY);
      const data = await response.json() as any;
      const functions = data?.data?.shopifyFunctions?.nodes || [];
      const paymentFunction = functions.find((f: any) =>
        f.apiType?.toLowerCase() === "payment_customization" || f.title?.toLowerCase().includes("payment") || f.title?.toLowerCase().includes("bypass")
      );
      if (!paymentFunction) return json({ success: false, errors: { general: "Payment customization function not found in shopifyFunctions" } });

      await admin.graphql(
        `mutation paymentCustomizationCreate($input: PaymentCustomizationInput!) {
          paymentCustomizationCreate(paymentCustomization: $input) {
            paymentCustomization { id }
            userErrors { field message }
          }
        }`,
        { variables: { input: { functionId: paymentFunction.id, title: "Discount Payment Rules", enabled: true } } }
      );
      return json({ success: true, actionType: "activatePaymentCustomization" });
    } catch (e: any) {
      return json({ success: false, errors: { general: e.message } });
    }
  }

  if (intent === "bulkActivate" || intent === "bulkDeactivate" || intent === "bulkDelete") {
    const ids = JSON.parse(formData.get("ids") as string || "[]");
    if (!Array.isArray(ids) || ids.length === 0) return json({ success: false, actionType: intent, errors: { general: "No discounts selected" } });

    const discounts = await prisma.discountThreshold.findMany({ where: { id: { in: ids }, shop } });

    if (intent === "bulkDelete") {
      // Fire all Shopify deletes in parallel
      await Promise.all(
        discounts.map((discount) =>
          admin.graphql(
            `mutation discountCodeDelete($id: ID!) { discountCodeDelete(id: $id) { userErrors { field message } } }`,
            { variables: { id: discount.discountGid } }
          ).catch((e) => console.error("GraphQL bulk delete failed:", e))
        )
      );
      await prisma.discountThreshold.deleteMany({ where: { id: { in: ids } } });
    } else {
      const mutationName = intent === "bulkActivate" ? "discountCodeActivate" : "discountCodeDeactivate";
      // Fire all Shopify activate/deactivate in parallel
      await Promise.all(
        discounts.map(async (discount) => {
          await admin.graphql(
            `mutation ${mutationName}($id: ID!) { ${mutationName}(id: $id) { userErrors { field message } } }`,
            { variables: { id: discount.discountGid } }
          ).catch((e: any) => console.error(`Failed to bulk ${intent}:`, e));
          // If activating and start date is in the future, restore startsAt so Shopify re-schedules it
          if (intent === "bulkActivate") {
            await restoreStartsAtIfFuture(admin, discount.discountGid, discount.startDate, null);
          }
        })
      );
      const isActive = intent === "bulkActivate";
      await prisma.discountThreshold.updateMany({
        where: { id: { in: ids } },
        data: { isActive },
      });
    }

    return json({ success: true, actionType: intent });
  }

  if (intent === "toggle") {
    const discount = await prisma.discountThreshold.findUnique({ where: { id } });
    if (discount && discount.shop === shop) {
      const currentActive = formData.get("currentIsActive") === "true";
      const newActive = !currentActive;
      const mutationName = newActive ? "discountCodeActivate" : "discountCodeDeactivate";

      try {
        await admin.graphql(
          `mutation ${mutationName}($id: ID!) { ${mutationName}(id: $id) { userErrors { field message } } }`,
          { variables: { id: discount.discountGid } }
        );
        // If activating and start date is in the future, restore startsAt so Shopify marks it as SCHEDULED
        if (newActive) {
          await restoreStartsAtIfFuture(admin, discount.discountGid, discount.startDate, null);
        }
      } catch (e) {
        console.error(`Failed to ${newActive ? "activate" : "deactivate"} discount code in Shopify:`, e);
      }

      await prisma.discountThreshold.update({
        where: { id },
        data: { isActive: newActive },
      });
    }
    return json({ success: true, actionType: "toggle" });
  }

  if (intent === "create") {
    const title = (formData.get("title") as string)?.trim();
    const code = (formData.get("code") as string)?.trim().toUpperCase();
    const discountType = formData.get("discountType") as string || "percentage";
    const percentageStr = formData.get("percentage") as string;
    const fixedValueStr = formData.get("fixedValue") as string;
    const thresholdStr = formData.get("threshold") as string;
    const startDateStr = formData.get("startDate") as string;
    const endDateStr = formData.get("endDate") as string;
    const discountCategory = formData.get("discountCategory") as string;
    const specialProducts = formData.get("specialProducts") as string;
    const paymentType = (formData.get("paymentType") as string) || "";

    const errors: Record<string, string> = {};
    if (!title) errors.title = "Title is required";
    if (!code || code.length < 3) errors.code = "Code must be at least 3 characters";
    if (!/^[A-Z0-9_-]+$/.test(code || "")) errors.code = "Code can only contain letters, numbers, dashes, and underscores";

    let percentage: number | null = null;
    let fixedValue: number | null = null;

    if (discountType === "percentage") {
      percentage = parseFloat(percentageStr);
      if (isNaN(percentage) || percentage <= 0 || percentage > 100) errors.percentage = "Percentage must be between 1 and 100";
    } else {
      fixedValue = parseFloat(fixedValueStr);
      if (isNaN(fixedValue) || fixedValue <= 0) errors.fixedValue = "Fixed value must be a positive number";
    }

    const threshold = parseFloat(thresholdStr);
    if (isNaN(threshold) || threshold <= 0) errors.threshold = "Threshold must be a positive number";

    // Cross-field: fixed discount amount cannot exceed the total budget
    if (discountType === "fixed" && fixedValue !== null && !isNaN(threshold) && fixedValue > threshold) {
      errors.fixedValue = "Fixed discount amount cannot be greater than the total threshold budget";
    }

    let startDate: Date;
    if (startDateStr) {
      const parts = startDateStr.split('-');
      startDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`);
    } else {
      startDate = new Date();
    }

    let endDate: Date | null = null;
    if (endDateStr) {
      const parts = endDateStr.split('-');
      endDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`);
    }

    if (endDate && endDate <= startDate) {
      errors.endDate = "End date must be after the start date";
    }

    let specialProductsParsed: any[] = [];
    if (specialProducts) {
      try {
        specialProductsParsed = JSON.parse(specialProducts);
      } catch (e) {}
    }
    specialProductsParsed.forEach((item) => {
      if (!item.productId) {
        errors[`specialProduct_${item.id}`] = "Please select a product";
      }
    });

    if (Object.keys(errors).length > 0) return json({ errors, success: false, actionType: "create" });

    const now = new Date();
    const existing = await prisma.discountThreshold.findFirst({
      where: {
        shop,
        discountCode: code,
        isActive: true,
        OR: [
          { endDate: null },
          { endDate: { gt: now } }
        ]
      }
    });
    if (existing) return json({ errors: { code: "An active/scheduled discount with this code already exists" }, success: false, actionType: "create" });

    // Rename any old duplicate/expired discounts in Shopify to release the code name
    const oldDuplicates = await prisma.discountThreshold.findMany({
      where: {
        shop,
        discountCode: code,
      }
    });

    for (const dup of oldDuplicates) {
      try {
        console.log(`[create] Renaming duplicate discount ${dup.discountGid} in Shopify to free up code name`);
        await admin.graphql(
          `mutation discountCodeAppUpdate($id: ID!, $discount: DiscountCodeAppInput!) {
            discountCodeAppUpdate(id: $id, codeAppDiscount: $discount) {
              userErrors { field message }
            }
          }`,
          {
            variables: {
              id: dup.discountGid,
              discount: {
                code: `${code}_EXPIRED_${dup.id.substring(0, 6)}`
              }
            }
          }
        );
      } catch (e) {
        console.error(`Failed to rename old duplicate discount ${dup.discountGid} in Shopify:`, e);
      }
    }

    if (oldDuplicates.length > 0) {
      await prisma.discountThreshold.updateMany({
        where: {
          id: { in: oldDuplicates.map(d => d.id) }
        },
        data: {
          isActive: false
        }
      });
    }

    let functionId: string | null = null;
    try {
      const response = await admin.graphql(GET_FUNCTIONS_QUERY);
      const data = await response.json() as any;
      const functions = data?.data?.shopifyFunctions?.nodes || [];
      const ourFunction = functions.find((f: any) =>
        f.title?.toLowerCase().includes("discount") || f.apiType?.toLowerCase().includes("discount")
      ) || functions[0];
      functionId = ourFunction?.id || null;
    } catch { }

    if (!functionId) return json({ errors: { general: "Shopify Function not found." }, success: false, actionType: "create" });

    let discountGid: string | null = null;
    try {
      const response = await admin.graphql(CREATE_DISCOUNT_MUTATION, {
        variables: {
          discount: {
            title, code, startsAt: startDate.toISOString(), ...(endDate ? { endsAt: endDate.toISOString() } : {}), functionId,
            combinesWith: { orderDiscounts: false, productDiscounts: false, shippingDiscounts: false },
            discountClasses: ["PRODUCT"],
          }
        }
      });
      const data = await response.json() as any;
      const userErrors = data?.data?.discountCodeAppCreate?.userErrors || [];
      if (userErrors.length > 0) {
        const fieldName = userErrors[0].field ? userErrors[0].field.join(".") : "";
        return json({ errors: { general: fieldName ? `${fieldName} ${userErrors[0].message}` : userErrors[0].message }, success: false, actionType: "create" });
      }
      discountGid = data?.data?.discountCodeAppCreate?.codeAppDiscount?.discountId;
    } catch (e: any) {
      return json({ errors: { general: e.message }, success: false, actionType: "create" });
    }

    if (!discountGid) return json({ errors: { general: "Failed to create discount in Shopify" }, success: false, actionType: "create" });

    const metafieldValue = JSON.stringify({ type: discountType, percentage, fixedAmount: fixedValue || 0, remaining_threshold: threshold, total_threshold: threshold, discountCategory, specialProducts });
    try {
      const mfs: any[] = [
        { ownerId: discountGid, namespace: "$app", key: "discount_config", type: "json", value: metafieldValue },
        { ownerId: discountGid, namespace: "$app", key: "payment_type", type: "single_line_text_field", value: paymentType || "None" },
      ];
      console.log("Saving create metafields with mfs:", JSON.stringify(mfs, null, 2));
      const res = await admin.graphql(SET_METAFIELD_MUTATION, { variables: { metafields: mfs } });
      const resJson = await res.json();
      console.log("create metafieldsSet response:", JSON.stringify(resJson, null, 2));
    } catch { }

    await prisma.discountThreshold.create({
      data: { shop, discountGid, discountCode: code, title, discountType, percentage, fixedValue, totalThreshold: threshold, remainingAmount: threshold, discountCategory, specialProducts, paymentType: paymentType || "None", isActive: true, startDate, endDate, version: 0 },
    });

    return json({ success: true, actionType: "create" });
  }

  if (intent === "edit") {
    const title = (formData.get("title") as string)?.trim();
    const discountType = formData.get("discountType") as string || "percentage";
    const percentageStr = formData.get("percentage") as string;
    const fixedValueStr = formData.get("fixedValue") as string;
    const thresholdStr = formData.get("threshold") as string;
    const startDateStr = formData.get("startDate") as string;
    const endDateStr = formData.get("endDate") as string;
    const discountCategory = formData.get("discountCategory") as string;
    const specialProducts = formData.get("specialProducts") as string;
    const paymentType = (formData.get("paymentType") as string) || "";

    const discount = await prisma.discountThreshold.findFirst({ where: { id, shop } });
    if (!discount) return json({ errors: { general: "Discount not found" }, success: false, actionType: "edit" });

    const errors: Record<string, string> = {};
    if (!title) errors.title = "Title is required";

    let percentage: number | null = null;
    let fixedValue: number | null = null;

    if (discountType === "percentage") {
      percentage = parseFloat(percentageStr);
      if (isNaN(percentage) || percentage <= 0 || percentage > 100) errors.percentage = "Percentage must be between 1 and 100";
    } else {
      fixedValue = parseFloat(fixedValueStr);
      if (isNaN(fixedValue) || fixedValue <= 0) errors.fixedValue = "Fixed value must be a positive number";
    }

    const newTotalThreshold = parseFloat(thresholdStr);
    if (isNaN(newTotalThreshold) || newTotalThreshold <= 0) errors.threshold = "Threshold must be a positive number";
    if (newTotalThreshold < discount.usedAmount) errors.threshold = `Cannot set threshold below already-used amount (₹${discount.usedAmount.toFixed(2)})`;

    // Cross-field: fixed discount amount cannot exceed the total budget
    if (discountType === "fixed" && fixedValue !== null && !isNaN(newTotalThreshold) && fixedValue > newTotalThreshold) {
      errors.fixedValue = "Fixed discount amount cannot be greater than the total threshold budget";
    }

    let startDate: Date;
    if (startDateStr) {
      const parts = startDateStr.split('-');
      startDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`);
    } else {
      startDate = new Date();
    }

    let endDate: Date | null = null;
    if (endDateStr) {
      const parts = endDateStr.split('-');
      endDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`);
    }

    if (endDate && endDate <= startDate) {
      errors.endDate = "End date must be after the start date";
    }

    let specialProductsParsed: any[] = [];
    if (specialProducts) {
      try {
        specialProductsParsed = JSON.parse(specialProducts);
      } catch (e) {}
    }
    specialProductsParsed.forEach((item) => {
      if (!item.productId) {
        errors[`specialProduct_${item.id}`] = "Please select a product";
      }
    });

    if (Object.keys(errors).length > 0) return json({ errors, success: false, actionType: "edit" });

    const newRemaining = newTotalThreshold - discount.usedAmount;
    const metafieldValue = JSON.stringify({ type: discountType, percentage, fixedAmount: fixedValue || 0, remaining_threshold: newRemaining, total_threshold: newTotalThreshold, discountCategory, specialProducts });

    try {
      await admin.graphql(UPDATE_DISCOUNT_MUTATION, {
        variables: {
          id: discount.discountGid,
          discount: {
            title,
            startsAt: startDate.toISOString(),
            ...(endDate ? { endsAt: endDate.toISOString() } : { endsAt: null }),
          }
        }
      });
      const mfs: any[] = [
        { ownerId: discount.discountGid, namespace: "$app", key: "discount_config", type: "json", value: metafieldValue },
        { ownerId: discount.discountGid, namespace: "$app", key: "payment_type", type: "single_line_text_field", value: paymentType || "None" },
      ];
      console.log("Saving metafields with mfs:", JSON.stringify(mfs, null, 2));
      const res = await admin.graphql(SET_METAFIELD_MUTATION, { variables: { metafields: mfs } });
      const resJson = await res.json();
      console.log("metafieldsSet response:", JSON.stringify(resJson, null, 2));
    } catch (e) {
      console.error("Error updating discount in Shopify:", e);
    }

    await prisma.discountThreshold.update({
      where: { id },
      data: { title, discountType, percentage, fixedValue, totalThreshold: newTotalThreshold, remainingAmount: newRemaining, discountCategory, specialProducts, paymentType: paymentType || "None", startDate, endDate, version: { increment: 1 } },
    });

    try {
      const limit = parseFloat(process.env.THRESHOLD_WARNING_LIMIT || "50");
      if (newRemaining >= limit) {
        await prisma.discountReminderLog.deleteMany({
          where: {
            discountId: id,
            reminderType: ReminderType.BELOW_THRESHOLD,
          },
        });
      }
    } catch (err) {
      console.error("Error clearing BELOW_THRESHOLD reminder log:", err);
    }

    try {
      if (discount.specialProducts !== specialProducts) {
        console.log(`[edit-discount] specialProducts changed. Clearing FREE_PRODUCT_OUT_OF_STOCK reminder log for discount ${id}`);
        await prisma.discountReminderLog.deleteMany({
          where: {
            discountId: id,
            reminderType: ReminderType.FREE_PRODUCT_OUT_OF_STOCK,
          },
        });
      }
    } catch (err) {
      console.error("Error clearing FREE_PRODUCT_OUT_OF_STOCK reminder log:", err);
    }

    return json({ success: true, actionType: "edit" });
  }

  return json({ success: false });
};

function CopyBadge({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [code]);

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ display: "inline-flex", alignItems: "center", gap: "6px" }}
    >
      <Badge tone="info">{code}</Badge>
      <Tooltip content={copied ? "Copied!" : "Copy Coupon code"}>
        <div
          onClick={handleCopy}
          style={{
            cursor: "pointer",
            opacity: isHovered || copied ? 1 : 0,
            transition: "opacity 0.2s",
            position: "relative", width: "20px", height: "20px",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <div style={{ position: "absolute", opacity: copied ? 0 : 1, transition: "opacity 0.2s" }}>
            <Icon source={ClipboardIcon} tone="base" />
          </div>
          <div style={{ position: "absolute", opacity: copied ? 1 : 0, transition: "opacity 0.2s" }}>
            <Icon source={CheckIcon} tone="success" />
          </div>
        </div>
      </Tooltip>
    </div>
  );
}

function getCurrencySymbol(currencyCode: string) {
  try {
    const parts = new Intl.NumberFormat("en", { style: "currency", currency: currencyCode, currencyDisplay: "narrowSymbol" }).formatToParts(0);
    return parts.find(p => p.type === "currency")?.value || currencyCode;
  } catch {
    return currencyCode;
  }
}

function formatCurrency(amount: number, currencyCode: string) {
  try {
    return new Intl.NumberFormat("en", {
      style: "currency",
      currency: currencyCode,
      minimumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${amount.toFixed(2)}`;
  }
}

export default function Index() {
  const { discounts, currencyCode, usageCounts, discountStatuses } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const submit = useSubmit();
  const navigation = useNavigation();
  const isSubmitting = (navigation.state === "submitting" && navigation.formData?.get("intent") === "create") || (navigation.state === "submitting" && navigation.formData?.get("intent") === "edit");

  const [view, setViewState] = useState<"list" | "create" | "edit">(() => {
    if (typeof window !== "undefined") {
      const p = new URLSearchParams(window.location.search);
      return (p.get("view") as "list" | "create" | "edit") || "list";
    }
    return "list";
  });
  const [selectedDiscountId, setSelectedDiscountId] = useState<string | null>(() => {
    if (typeof window !== "undefined") {
      return new URLSearchParams(window.location.search).get("id");
    }
    return null;
  });

  const setView = useCallback((v: "list" | "create" | "edit", id?: string) => {
    setViewState(v);
    setSelectedDiscountId(id || null);
    // Silently update URL for reload persistence — no Remix navigation triggered
    if (typeof window !== "undefined") {
      const params = new URLSearchParams();
      if (v !== "list") params.set("view", v);
      if (v === "edit" && id) params.set("id", id);
      const qs = params.toString();
      window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
    }
  }, []);
  // const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [toastActive, setToastActive] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  const errors = (actionData as any)?.errors || {};

  useEffect(() => {
    if (actionData?.success) {
      if (actionData.actionType === "create") {
        setView("list");
        setToastMessage("Discount created successfully");
        setToastActive(true);
      } else if (actionData.actionType === "edit") {
        setView("list");
        setToastMessage("Discount updated successfully");
        setToastActive(true);
      } else if (actionData.actionType === "delete") {
        setView("list");
        setToastMessage("Discount deleted successfully");
        setToastActive(true);
      } else if (actionData.actionType === "toggle") {
        setToastMessage("Discount status updated");
        setToastActive(true);
      } else if (actionData.actionType === "bulkActivate") {
        setToastMessage("Discounts activated successfully");
        setToastActive(true);
      } else if (actionData.actionType === "bulkDeactivate") {
        setToastMessage("Discounts deactivated successfully");
        setToastActive(true);
      } else if (actionData.actionType === "bulkDelete") {
        setView("list");
        setToastMessage("Discounts deleted successfully");
        setToastActive(true);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actionData]);

  const [deleteTargetIds, setDeleteTargetIds] = useState<string[] | null>(null);

  const confirmDelete = useCallback(() => {
    if (!deleteTargetIds || deleteTargetIds.length === 0) return;
    const formData = new FormData();
    if (deleteTargetIds.length === 1) {
      formData.set("intent", "delete");
      formData.set("id", deleteTargetIds[0]);
    } else {
      formData.set("intent", "bulkDelete");
      formData.set("ids", JSON.stringify(deleteTargetIds));
    }
    submit(formData, { method: "post" });
    setDeleteTargetIds(null);
  }, [deleteTargetIds, submit]);

  // const handleToggle = useCallback((id: string, currentIsActive: boolean) => {
  //   const formData = new FormData();
  //   formData.set("intent", "toggle");
  //   formData.set("id", id);
  //   formData.set("currentIsActive", String(currentIsActive));
  //   submit(formData, { method: "post" });
  // }, [submit]);

  const [selectedTab, setSelectedTab] = useState(0);
  const { mode, setMode } = useSetIndexFiltersMode();
  const [queryValue, setQueryValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 20;

  const tabs = ['All', 'Active', 'Scheduled', 'Expired'].map((item, index) => ({
    content: item,
    id: `${item}-${index}`,
    onAction: () => setSelectedTab(index),
  }));

  const filteredDiscounts = discounts.filter((d: any) => {
    let status = discountStatuses[d.id] || "";
    if (!status) {
      const now = new Date();
      if (d.endDate && new Date(d.endDate) <= now) {
        status = "EXPIRED";
      } else if (!d.isActive) {
        status = "INACTIVE";
      } else if (new Date(d.startDate) > now) {
        status = "SCHEDULED";
      } else {
        status = "ACTIVE";
      }
    }

    if (queryValue && !d.title.toLowerCase().includes(queryValue.toLowerCase()) && !d.discountCode.toLowerCase().includes(queryValue.toLowerCase())) {
      return false;
    }
    if (selectedTab === 1 && status !== 'ACTIVE') return false;
    if (selectedTab === 2 && status !== 'SCHEDULED') return false;
    if (selectedTab === 3 && status !== 'EXPIRED') return false;

    return true;
  });

  // Reset to page 1 when filters change
  useEffect(() => { setCurrentPage(1); }, [queryValue, selectedTab]);

  const totalPages = Math.max(1, Math.ceil(filteredDiscounts.length / PAGE_SIZE));
  const paginatedDiscounts = filteredDiscounts.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const startIndex = filteredDiscounts.length === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1;
  const endIndex = Math.min(currentPage * PAGE_SIZE, filteredDiscounts.length);

  const { selectedResources, allResourcesSelected, handleSelectionChange, clearSelection } = useIndexResourceState(filteredDiscounts as any);

  const handleBulkAction = useCallback((intent: string) => {
    const formData = new FormData();
    formData.set("intent", intent);
    formData.set("ids", JSON.stringify(selectedResources));
    submit(formData, { method: "post" });
    clearSelection();
  }, [selectedResources, submit, clearSelection]);

  const rowMarkup = paginatedDiscounts.map((d: any, index: number) => {
    let status = discountStatuses[d.id] || "";
    if (!status) {
      const now = new Date();
      if (d.endDate && new Date(d.endDate) <= now) {
        status = "EXPIRED";
      } else if (!d.isActive) {
        status = "INACTIVE";
      } else if (new Date(d.startDate) > now) {
        status = "SCHEDULED";
      } else {
        status = "ACTIVE";
      }
    }
    const isActive = status === 'ACTIVE' || status === 'SCHEDULED';
    const startDateLabel = d.startDate ? new Date(d.startDate).toLocaleDateString([], { day: '2-digit', month: '2-digit', year: '2-digit' }) : "-";
    const endDateLabel = d.endDate ? new Date(d.endDate).toLocaleDateString([], { day: '2-digit', month: '2-digit', year: '2-digit' }) : " ";
    const activeDatesLabel = d.endDate ? `${startDateLabel} — ${endDateLabel}` : startDateLabel;

    return (
      <IndexTable.Row id={d.id} key={d.id} selected={selectedResources.includes(d.id)} position={index}>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            <Tooltip content="Edit discount" dismissOnMouseOut>
              <div
                onClick={(e) => { e.stopPropagation(); setView("edit", d.id); }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.textDecoration = "underline"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.textDecoration = "none"; }}
                style={{ cursor: "pointer", display: "inline" }}
              >
                <Text as="span" variant="bodyMd" fontWeight="semibold" tone="subdued">{d.title}</Text>
              </div>
            </Tooltip>
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            <CopyBadge code={d.discountCode} />
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            {d.discountType === "fixed" ? formatCurrency(d.fixedValue, currencyCode) : `${d.percentage}%`}
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            {formatCurrency(d.totalThreshold, currencyCode)}
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            {formatCurrency(d.usedAmount, currencyCode)}
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            <Text as="span" tone={d.remainingAmount > 0 ? "success" : "critical"}>
              {formatCurrency(d.remainingAmount, currencyCode)}
            </Text>
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            {activeDatesLabel}
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            <Text as="span">{usageCounts[d.id] ?? 0}</Text>
          </Box>
        </IndexTable.Cell>
        <IndexTable.Cell>
          <Box paddingBlock="300">
            <Badge tone={status === 'SCHEDULED' ? "attention" : (isActive ? "success" : status === "EXPIRED" ? "enabled" : "enabled")}>
              {status ? status.charAt(0) + status.slice(1).toLowerCase() : (d.isActive ? "Active" : "Inactive")}
            </Badge>
          </Box>
        </IndexTable.Cell>
      </IndexTable.Row>
    );
  });


  // function RowActions({ id, isActive, onEdit, onToggle, onDelete }: { id: string, isActive: boolean, onEdit: () => void, onToggle: () => void, onDelete: () => void }) {
  //   const [popoverActive, setPopoverActive] = useState(false);
  //   return (
  //     <Popover
  //       active={popoverActive}
  //       activator={<Button variant="tertiary" icon={MenuHorizontalIcon} onClick={() => setPopoverActive((a) => !a)} />}
  //       onClose={() => setPopoverActive(false)}
  //       autofocusTarget="first-node"
  //     >
  //       <ActionList
  //         actionRole="menuitem"
  //         items={[
  //           { content: 'Edit', onAction: () => { setPopoverActive(false); onEdit(); } },
  //           { content: isActive ? 'Deactivate' : 'Activate', destructive: isActive, onAction: () => { setPopoverActive(false); onToggle(); } },
  //           { content: 'Delete', destructive: true, onAction: () => { setPopoverActive(false); onDelete(); } },
  //         ]}
  //       />
  //     </Popover>
  //   );
  // }

  function DateSelectionPicker({ label, dateStr, onChange, helpText, error }: { label: string, dateStr: string, onChange: (date: string) => void, helpText?: string, error?: string }) {
    const [popoverActive, setPopoverActive] = useState(false);

    // Default to today if dateStr is empty, or parse DD-MM-YYYY
    let selectedDate = new Date();
    if (dateStr) {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        selectedDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`);
      }
    }
    if (isNaN(selectedDate.getTime())) {
      selectedDate = new Date();
    }

    // Polaris DatePicker expects { month, year } object for the view
    const [{ month, year }, setDate] = useState({
      month: selectedDate.getMonth(),
      year: selectedDate.getFullYear(),
    });

    const handleMonthChange = useCallback((month: number, year: number) => setDate({ month, year }), []);

    const handleDateSelection = useCallback(
      ({ end: newSelectedDate }: { end: Date }) => {
        setPopoverActive(false);
        // Format to DD-MM-YYYY consistently
        const dd = String(newSelectedDate.getDate()).padStart(2, '0');
        const mm = String(newSelectedDate.getMonth() + 1).padStart(2, '0');
        const yyyy = newSelectedDate.getFullYear();
        onChange(`${dd}-${mm}-${yyyy}`);
      },
      [onChange]
    );

    const displayValue = dateStr ? dateStr : "Select Date (DD-MM-YYYY)";

    return (
      <Popover
        active={popoverActive}
        autofocusTarget="none"
        preferredAlignment="left"
        fullWidth
        preferInputActivator={false}
        preferredPosition="below"
        preventCloseOnChildOverlayClick
        onClose={() => setPopoverActive(false)}
        activator={
          <div style={{ position: "relative" }}>
            <TextField
              label={label}
              value={displayValue}
              onChange={() => { }}
              onFocus={() => setPopoverActive(true)}
              autoComplete="off"
              helpText={helpText}
              error={error}
              prefix={<Icon source={CalendarIcon} />}
            />
            {/* Hidden overlay to capture clicks without interfering with input styles */}
            <div
              style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, cursor: 'pointer', zIndex: 10 }}
              onClick={() => setPopoverActive(!popoverActive)}
            />
            {/* Hidden input to ensure the value reaches Remix Form POST */}
            <input type="hidden" name={label === "Start Date" ? "startDate" : "endDate"} value={dateStr} />
          </div>
        }
      >
        <Card>
          <DatePicker
            month={month}
            year={year}
            selected={selectedDate}
            onMonthChange={handleMonthChange}
            onChange={handleDateSelection}
          />
        </Card>
      </Popover>
    );
  }

  if (view === "create") {
    return <CreateDiscountView onCancel={() => setView("list")} errors={errors} isSubmitting={isSubmitting} currencyCode={currencyCode} DateSelectionPicker={DateSelectionPicker} />;
  }

  if (view === "edit" && selectedDiscountId) {
    const discount = discounts.find((d: any) => d.id === selectedDiscountId);
    if (!discount) { setView("list"); return null; }
    return <EditDiscountView discount={discount} onCancel={() => setView("list")} errors={errors} isSubmitting={isSubmitting} currencyCode={currencyCode} DateSelectionPicker={DateSelectionPicker} />;
  }

  return (
    <Frame>
      <Page
        fullWidth
        title="Discount Threshold"
        primaryAction={{ content: "Create Discount", onAction: () => setView("create", undefined) }}
        secondaryActions={[
          {
            content: "Activate Payment Customization",
            onAction: () => {
              const formData = new FormData();
              formData.set("intent", "activatePaymentCustomization");
              submit(formData, { method: "post" });
            }
          }
        ]}
      >
        <Layout>
          <Layout.Section>
            <Card padding="0">
              {discounts.length === 0 ? (
                <Box padding="400">
                  <EmptyState heading="No discount codes yet" image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png" action={{ content: "Create your first discount", onAction: () => setView("create", undefined) }}>
                    <p>Create discount codes with a threshold budget to control total discount spend.</p>
                  </EmptyState>
                </Box>
              ) : (
                <>
                  <IndexFilters
                    sortOptions={[]}
                    sortSelected={[]}
                    onSort={() => { }}
                    queryValue={queryValue}
                    queryPlaceholder="Searching in all"
                    onQueryChange={setQueryValue}
                    onQueryClear={() => setQueryValue('')}
                    primaryAction={{ type: 'save', onAction: async () => true, disabled: false, loading: false }}
                    cancelAction={{ onAction: () => { }, disabled: false, loading: false }}
                    tabs={tabs}
                    selected={selectedTab}
                    onSelect={setSelectedTab}
                    canCreateNewView={false}
                    filters={[]}
                    appliedFilters={[]}
                    onClearAll={() => { }}
                    mode={mode}
                    setMode={setMode}
                  />
                  <IndexTable
                    resourceName={{ singular: 'discount', plural: 'discounts' }}
                    itemCount={filteredDiscounts.length}
                    selectedItemsCount={allResourcesSelected ? 'All' : selectedResources.length}
                    onSelectionChange={handleSelectionChange}
                    promotedBulkActions={[
                      {
                        content: 'Activate discounts',
                        onAction: () => handleBulkAction("bulkActivate"),
                      },
                      {
                        content: 'Deactivate discounts',
                        onAction: () => handleBulkAction("bulkDeactivate"),
                      },
                      {
                        content: 'Delete discounts',
                        onAction: () => {
                          setDeleteTargetIds(selectedResources);
                          clearSelection();
                        },
                      },
                    ]}
                    headings={[
                      { title: "Name" },
                      { title: "Coupon Code" },
                      { title: "Discount" },
                      { title: "Total Budget" },
                      { title: "Used" },
                      { title: "Remaining" },
                      { title: "Active Dates" },
                      { title: "Code Used" },
                      { title: "Status" },
                    ]}
                  >
                    {rowMarkup}
                  </IndexTable>
                  <Box
                    paddingInline="300"
                    paddingBlock="300"
                    borderBlockStartWidth="025"
                    borderColor="border"
                  >
                    <InlineStack align="space-between" blockAlign="center">
                      <Text as="p" tone="subdued" variant="bodySm">
                        {filteredDiscounts.length === 0
                          ? "No discounts"
                          : `${startIndex}–${endIndex} of ${filteredDiscounts.length} discounts`}
                      </Text>
                      <Pagination
                        hasPrevious={currentPage > 1}
                        onPrevious={() => setCurrentPage((p) => Math.max(1, p - 1))}
                        hasNext={currentPage < totalPages}
                        onNext={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      />
                    </InlineStack>
                  </Box>
                </>
              )}
            </Card>
          </Layout.Section>
        </Layout>
        {/* <FooterHelp>
          Learn more about{" "}
          <Link url="https://help.shopify.com/manual/discounts" target="_blank">
            discounts
          </Link>
        </FooterHelp> */}
        <Modal
          open={!!deleteTargetIds && deleteTargetIds.length > 0}
          onClose={() => setDeleteTargetIds(null)}
          title={`Delete ${deleteTargetIds?.length === 1 ? 'discount code' : 'discount codes'}?`}
          primaryAction={{ content: "Delete", destructive: true, onAction: confirmDelete, loading: navigation.state === "submitting" && (navigation.formData?.get("intent") === "delete" || navigation.formData?.get("intent") === "bulkDelete") }}
          secondaryActions={[{ content: "Cancel", onAction: () => setDeleteTargetIds(null) }]}
        >
          <Modal.Section>
            <BlockStack gap="200">
              <Text as="p">This will permanently delete the selected discount(s) from both your app and Shopify.</Text>
              <Text as="p" tone="critical">This action cannot be undone.</Text>
            </BlockStack>
          </Modal.Section>
        </Modal>
        {toastActive && <Toast content={toastMessage} onDismiss={() => setToastActive(false)} />}
      </Page>
    </Frame>
  );
}

function CreateDiscountView({ onCancel, errors: propErrors, isSubmitting, currencyCode, DateSelectionPicker }: Record<string, any>) {
  const [errors, setErrors] = useState(propErrors || {});
  useEffect(() => {
    setErrors(propErrors || {});
  }, [propErrors]);

  const [title, setTitle] = useState("");
  const [code, setCode] = useState("");
  const [discountType, setDiscountType] = useState("percentage");
  const [percentage, setPercentage] = useState("");
  const [fixedValue, setFixedValue] = useState("");
  const [threshold, setThreshold] = useState("");
  const [discountCategory, setDiscountCategory] = useState(DISCOUNT_CATEGORIES[0]);
  const [paymentType, setPaymentType] = useState("");

  const handleTitleChange = useCallback((v: string) => {
    setTitle(v);
    if (v.trim()) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.title;
        return next;
      });
    }
  }, []);

  const handleCodeChange = useCallback((v: string) => {
    const uppercaseVal = v.toUpperCase().replace(/[^A-Z0-9_-]/g, "");
    setCode(uppercaseVal);
    if (uppercaseVal.length >= 3) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.code;
        return next;
      });
    }
  }, []);

  const handlePercentageChange = useCallback((v: string) => {
    setPercentage(v);
    const parsed = parseFloat(v);
    if (!isNaN(parsed) && parsed > 0 && parsed <= 100) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.percentage;
        return next;
      });
    }
  }, []);

  const handleFixedValueChange = useCallback((v: string) => {
    setFixedValue(v);
    const parsed = parseFloat(v);
    if (!isNaN(parsed) && parsed > 0) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.fixedValue;
        return next;
      });
    }
  }, []);

  const handleThresholdChange = useCallback((v: string) => {
    setThreshold(v);
    const parsed = parseFloat(v);
    if (!isNaN(parsed) && parsed > 0) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.threshold;
        return next;
      });
    }
  }, []);

  const [toastActive, setToastActive] = useState(false);
  const [toastMessage, setToastMessage] = useState("");
  const [specialProducts, setSpecialProducts] = useState<Array<{ id: string, productId: string, productTitle: string, category: string, quantity: number, variants?: any[] }>>([]);
  const handleAddProductRow = useCallback(() => {
    setSpecialProducts((prev) => [...prev, { id: Math.random().toString(), productId: "", productTitle: "", category: DISCOUNT_CATEGORIES[0], quantity: 1 }]);
  }, []);
  const handleRemoveProductRow = useCallback((id: string) => {
    setSpecialProducts((prev) => prev.filter(row => row.id !== id));
  }, []);
  const handleProductSelect = useCallback(async (id: string) => {
    const currentRow = specialProducts.find(r => r.id === id);
    const selectionIds = currentRow?.productId ? [{
      id: currentRow.productId,
      variants: currentRow.variants || []
    }] : [];
    const selected = await window.shopify.resourcePicker({
      type: 'product',
      multiple: false,
      action: 'select',
      selectionIds,
      filter: {
        query: "inventory_total:>0"
      }
    });
    if (selected && selected.length > 0) {
      const productId = selected[0].id;
      let inStockVariantIds: string[] = [];
      let apiSucceeded = false;
      try {
        const response = await fetch(`/app/api/variants-inventory?productId=${encodeURIComponent(productId)}`);
        if (response.ok) {
          const result = await response.json();
          if (result && result.inStockVariants) {
            inStockVariantIds = result.inStockVariants;
            apiSucceeded = true;
          } else if (result && result.error) {
            console.error("API variants-inventory error:", result.error);
          }
        }
      } catch (e) {
        console.error("Failed to fetch variant inventories:", e);
      }

      // Convert GIDs to numeric IDs for robust matching
      const getNumericId = (gid: string) => {
        if (!gid) return "";
        const parts = gid.split("/");
        return parts[parts.length - 1];
      };

      const originalVariantsCount = selected[0].variants ? selected[0].variants.length : 0;

      // Filter variants: only keep ones that match the in-stock numeric IDs returned by backend
      const selectedVariants = selected[0].variants
        ? selected[0].variants
            .filter((v: any) => {
              const vNum = getNumericId(v.id);
              return inStockVariantIds.some((inStockId) => getNumericId(inStockId) === vNum);
            })
            .map((v: any) => ({ id: v.id }))
        : [];

      // Fallback: If the API failed to return any in-stock variants, but the picker returned some,
      // keep the picker's selection to avoid empty array falling back to "all variants" in the checkout discount webhook.
      const finalVariants = !apiSucceeded && selectedVariants.length === 0 && selected[0].variants && selected[0].variants.length > 0
        ? selected[0].variants.map((v: any) => ({ id: v.id }))
        : selectedVariants;

      if (apiSucceeded && finalVariants.length === 0) {
        setToastMessage(`"${selected[0].title}" has no variants in stock and cannot be added.`);
        setToastActive(true);
        setSpecialProducts((prev) => prev.map(row =>
          row.id === id ? { ...row, productId: "", productTitle: "", variants: [] } : row
        ));
        setErrors((prev: any) => ({
          ...prev,
          [`specialProduct_${id}`]: "This product is completely out of stock"
        }));
        return;
      }

      const filteredCount = originalVariantsCount - finalVariants.length;
      if (filteredCount > 0) {
        setToastMessage(`Removed ${filteredCount} out-of-stock variant(s) of "${selected[0].title}".`);
        setToastActive(true);
      }

      setSpecialProducts((prev) => prev.map(row =>
        row.id === id ? { ...row, productId: selected[0].id, productTitle: selected[0].title, variants: finalVariants } : row
      ));
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next[`specialProduct_${id}`];
        return next;
      });
    }
  }, [specialProducts]);
  const handleCategoryChange = useCallback((id: string, value: string) => {
    setSpecialProducts((prev) => prev.map(row =>
      row.id === id ? { ...row, category: value } : row
    ));
  }, []);
  const handleQuantityChange = useCallback((id: string, value: string) => {
    setSpecialProducts((prev) => prev.map(row =>
      row.id === id ? { ...row, quantity: parseInt(value, 10) || 1 } : row
    ));
  }, []);

  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
  });
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
  });
  const [endDateChanged, setEndDateChanged] = useState(false);

  const handleStartDateChange = useCallback((v: string) => {
    setStartDate(v);
    if (v) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.startDate;
        return next;
      });
    }
    if (!endDateChanged && v) {
      // Parse DD-MM-YYYY
      const parts = v.split('-');
      if (parts.length === 3) {
        const d = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`);
        if (!isNaN(d.getTime())) {
          d.setMonth(d.getMonth() + 1);
          const dd = String(d.getDate()).padStart(2, '0');
          const mm = String(d.getMonth() + 1).padStart(2, '0');
          const yyyy = d.getFullYear();
          setEndDate(`${dd}-${mm}-${yyyy}`);
        }
      }
    }
  }, [endDateChanged]);

  const handleEndDateChange = useCallback((v: string) => {
    setEndDate(v);
    setEndDateChanged(true);
    if (v) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.endDate;
        return next;
      });
    }
  }, []);

  return (
    <Frame>
      <Page title="Create Discount Code" backAction={{ content: "Discount Codes", onAction: onCancel }}>
      <Layout>
        {errors.general && <Layout.Section><Banner tone="critical" title="Error"><p>{errors.general}</p></Banner></Layout.Section>}
        <Layout.Section>
          <Form method="post">
            <input type="hidden" name="intent" value="create" />
            <BlockStack gap="500">
              <Card>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingMd">Discount Details</Text>
                  <FormLayout>
                    <TextField label="Name" name="title" value={title} onChange={handleTitleChange} helpText="Internal name for this discount" error={errors.title} autoComplete="off" />
                    <TextField label="Coupon Code" name="code" value={code} onChange={handleCodeChange} helpText="Customers enter this code at checkout. Uppercase only." error={errors.code} autoComplete="off" />
                  </FormLayout>
                </BlockStack>
              </Card>
              <Card>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingMd">Discount Configuration</Text>
                  <FormLayout>
                    <Select label="Discount Type" name="discountType" options={[{ label: "Percentage", value: "percentage" }, { label: "Fixed Amount", value: "fixed" }]} value={discountType} onChange={setDiscountType} />
                    <Select label="Discount Category" name="discountCategory" options={DISCOUNT_CATEGORIES} value={discountCategory} onChange={setDiscountCategory} />
                    <Select
                      label="Payment Method (Optional)"
                      name="paymentType"
                      options={[
                        { label: "-- No restriction --", value: "" },
                        { label: "Credit Card", value: "Credit Card" },
                        { label: "Net 10", value: "Net 10" },
                        { label: "Net 30", value: "Net 30" },
                        { label: "Net 31", value: "Net 31" },
                        { label: "Net 60", value: "Net 60" },
                        { label: "Net 180", value: "Net 180" },
                        { label: "1% 10, Net 30", value: "1% 10, Net 30" },
                        { label: "1% 15, Net 30", value: "1% 15, Net 30" },
                        { label: "2% 15, Net 30", value: "2% 15, Net 30" },
                        { label: "2% 30, Net 31", value: "2% 30, Net 31" },
                        { label: "2% 31, Net 31", value: "2% 31, Net 31" },
                      ]}
                      value={paymentType}
                      onChange={setPaymentType}
                      helpText="If selected, restricts checkout to this payment method"
                    />

                    <FormLayout.Group>
                      {discountType === "percentage" ? (
                        <TextField label="Discount Percentage" name="percentage" value={percentage} onChange={handlePercentageChange} suffix="%" type="number" helpText="Percentage off the order subtotal (1–100)" error={errors.percentage} autoComplete="off" />
                      ) : (() => {
                        const fixedNum = parseFloat(fixedValue);
                        const threshNum = parseFloat(threshold);
                        const fixedClientError = (!isNaN(fixedNum) && !isNaN(threshNum) && fixedNum > threshNum)
                          ? "Fixed discount amount cannot be greater than the total threshold budget"
                          : errors.fixedValue;
                        return <TextField label="Fixed Discount Amount" name="fixedValue" value={fixedValue} onChange={handleFixedValueChange} prefix={getCurrencySymbol(currencyCode)} type="number" helpText="Flat deduction from subtotal" error={fixedClientError} autoComplete="off" />;
                      })()}
                      <TextField label="Threshold Budget" name="threshold" value={threshold} onChange={handleThresholdChange} prefix={getCurrencySymbol(currencyCode)} type="number" helpText="Maximum total discount amount" error={errors.threshold} autoComplete="off" />
                    </FormLayout.Group>
                    <FormLayout.Group>
                      <DateSelectionPicker label="Start Date" dateStr={startDate} onChange={handleStartDateChange} error={errors.startDate} />
                      <DateSelectionPicker label="End Date" dateStr={endDate} onChange={handleEndDateChange} helpText="Defaults to 1 month after start date" error={errors.endDate} />
                    </FormLayout.Group>
                  </FormLayout>
                </BlockStack>
              </Card>
              <Card>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingMd">Free Products Mapping</Text>
                  {specialProducts.map((row) => (
                    <InlineStack key={row.id} gap="300" blockAlign="start">
                      <Box minWidth="300px">
                        <TextField
                          label="Product"
                          value={row.productTitle}
                          onChange={() => { }}
                          autoComplete="off"
                          connectedRight={<Button onClick={() => handleProductSelect(row.id)}>Browse</Button>}
                          error={errors[`specialProduct_${row.id}`]}
                        />
                      </Box>
                      <Box minWidth="100px">
                        <TextField
                          label="Quantity"
                          type="number"
                          value={row.quantity !== undefined ? String(row.quantity) : "1"}
                          onChange={(v) => handleQuantityChange(row.id, v)}
                          autoComplete="off"
                          min={1}
                        />
                      </Box>
                      <Box minWidth="250px">
                        <Select
                          label="Discount Category"
                          options={DISCOUNT_CATEGORIES}
                          value={row.category}
                          onChange={(v) => handleCategoryChange(row.id, v)}
                        />
                      </Box>
                      <div style={{ marginTop: "24px" }}>
                        <Button tone="critical" onClick={() => handleRemoveProductRow(row.id)}>Remove</Button>
                      </div>
                    </InlineStack>
                  ))}
                  <InlineStack>
                    <Button onClick={handleAddProductRow}>Add Product Row</Button>
                  </InlineStack>
                </BlockStack>
                <input type="hidden" name="specialProducts" value={JSON.stringify(specialProducts)} />
              </Card>
              <Divider />
              <InlineStack gap="300" align="end">
                <Button onClick={onCancel}>Cancel</Button>
                <Button variant="primary" submit loading={isSubmitting}>Create Discount</Button>
              </InlineStack>
            </BlockStack>
          </Form>
        </Layout.Section>
      </Layout>
      {toastActive && <Toast content={toastMessage} onDismiss={() => setToastActive(false)} />}
    </Page>
    </Frame>
  );
}

function EditDiscountView({ discount, onCancel, errors: propErrors, isSubmitting, currencyCode, DateSelectionPicker }: Record<string, any>) {
  const [errors, setErrors] = useState(propErrors || {});
  useEffect(() => {
    setErrors(propErrors || {});
  }, [propErrors]);

  const [title, setTitle] = useState(discount.title);
  const [discountType, setDiscountType] = useState(discount.discountType || "percentage");
  const [percentage, setPercentage] = useState(discount.percentage ? String(discount.percentage) : "");
  const [fixedValue, setFixedValue] = useState(discount.fixedValue ? String(discount.fixedValue) : "");
  const [threshold, setThreshold] = useState(String(discount.totalThreshold));
  const [discountCategory, setDiscountCategory] = useState(discount.discountCategory || DISCOUNT_CATEGORIES[0]);
  const [paymentType, setPaymentType] = useState(discount.paymentType && discount.paymentType !== "None" ? discount.paymentType : "");

  const handleTitleChange = useCallback((v: string) => {
    setTitle(v);
    if (v.trim()) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.title;
        return next;
      });
    }
  }, []);

  const handlePercentageChange = useCallback((v: string) => {
    setPercentage(v);
    const parsed = parseFloat(v);
    if (!isNaN(parsed) && parsed > 0 && parsed <= 100) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.percentage;
        return next;
      });
    }
  }, []);

  const handleFixedValueChange = useCallback((v: string) => {
    setFixedValue(v);
    const parsed = parseFloat(v);
    if (!isNaN(parsed) && parsed > 0) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.fixedValue;
        return next;
      });
    }
  }, []);

  const handleThresholdChange = useCallback((v: string) => {
    setThreshold(v);
    const parsed = parseFloat(v);
    if (!isNaN(parsed) && parsed > 0) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.threshold;
        return next;
      });
    }
  }, []);

  const [toastActive, setToastActive] = useState(false);
  const [toastMessage, setToastMessage] = useState("");
  const [specialProducts, setSpecialProducts] = useState<Array<{ id: string, productId: string, productTitle: string, category: string, quantity: number, variants?: any[] }>>(() => {
    if (discount.specialProducts) {
      try {
        const parsed = JSON.parse(discount.specialProducts);
        return parsed.map((item: any) => ({
          ...item,
          quantity: typeof item.quantity === 'number' ? item.quantity : 1
        }));
      } catch (e) { }
    }
    return [];
  });
  const handleAddProductRow = useCallback(() => {
    setSpecialProducts((prev) => [...prev, { id: Math.random().toString(), productId: "", productTitle: "", category: DISCOUNT_CATEGORIES[0], quantity: 1 }]);
  }, []);
  const handleRemoveProductRow = useCallback((id: string) => {
    setSpecialProducts((prev) => prev.filter(row => row.id !== id));
  }, []);
  const handleProductSelect = useCallback(async (id: string) => {
    const currentRow = specialProducts.find(r => r.id === id);
    const selectionIds = currentRow?.productId ? [{
      id: currentRow.productId,
      variants: currentRow.variants || []
    }] : [];
    const selected = await window.shopify.resourcePicker({
      type: 'product',
      multiple: false,
      action: 'select',
      selectionIds,
      filter: {
        query: "inventory_total:>0"
      }
    });
    if (selected && selected.length > 0) {
      const productId = selected[0].id;
      let inStockVariantIds: string[] = [];
      let apiSucceeded = false;
      try {
        const response = await fetch(`/app/api/variants-inventory?productId=${encodeURIComponent(productId)}`);
        if (response.ok) {
          const result = await response.json();
          if (result && result.inStockVariants) {
            inStockVariantIds = result.inStockVariants;
            apiSucceeded = true;
          } else if (result && result.error) {
            console.error("API variants-inventory error:", result.error);
          }
        }
      } catch (e) {
        console.error("Failed to fetch variant inventories:", e);
      }

      // Convert GIDs to numeric IDs for robust matching
      const getNumericId = (gid: string) => {
        if (!gid) return "";
        const parts = gid.split("/");
        return parts[parts.length - 1];
      };

      const originalVariantsCount = selected[0].variants ? selected[0].variants.length : 0;

      // Filter variants: only keep ones that match the in-stock numeric IDs returned by backend
      const selectedVariants = selected[0].variants
        ? selected[0].variants
            .filter((v: any) => {
              const vNum = getNumericId(v.id);
              return inStockVariantIds.some((inStockId) => getNumericId(inStockId) === vNum);
            })
            .map((v: any) => ({ id: v.id }))
        : [];

      // Fallback: If the API failed to return any in-stock variants, but the picker returned some,
      // keep the picker's selection to avoid empty array falling back to "all variants" in the checkout discount webhook.
      const finalVariants = !apiSucceeded && selectedVariants.length === 0 && selected[0].variants && selected[0].variants.length > 0
        ? selected[0].variants.map((v: any) => ({ id: v.id }))
        : selectedVariants;

      if (apiSucceeded && finalVariants.length === 0) {
        setToastMessage(`"${selected[0].title}" has no variants in stock and cannot be added.`);
        setToastActive(true);
        setSpecialProducts((prev) => prev.map(row =>
          row.id === id ? { ...row, productId: "", productTitle: "", variants: [] } : row
        ));
        setErrors((prev: any) => ({
          ...prev,
          [`specialProduct_${id}`]: "This product is completely out of stock"
        }));
        return;
      }

      const filteredCount = originalVariantsCount - finalVariants.length;
      if (filteredCount > 0) {
        setToastMessage(`Removed ${filteredCount} out-of-stock variant(s) of "${selected[0].title}".`);
        setToastActive(true);
      }

      setSpecialProducts((prev) => prev.map(row =>
        row.id === id ? { ...row, productId: selected[0].id, productTitle: selected[0].title, variants: finalVariants } : row
      ));
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next[`specialProduct_${id}`];
        return next;
      });
    }
  }, [specialProducts]);
  const handleCategoryChange = useCallback((id: string, value: string) => {
    setSpecialProducts((prev) => prev.map(row =>
      row.id === id ? { ...row, category: value } : row
    ));
  }, []);
  const handleQuantityChange = useCallback((id: string, value: string) => {
    setSpecialProducts((prev) => prev.map(row =>
      row.id === id ? { ...row, quantity: parseInt(value, 10) || 1 } : row
    ));
  }, []);

  const [startDate, setStartDate] = useState(() => {
    if (discount.startDate) {
      const d = new Date(discount.startDate);
      const dd = String(d.getDate()).padStart(2, '0');
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const yyyy = d.getFullYear();
      return `${dd}-${mm}-${yyyy}`;
    }
    return "";
  });
  const [endDate, setEndDate] = useState(() => {
    if (discount.endDate) {
      const d = new Date(discount.endDate);
      const dd = String(d.getDate()).padStart(2, '0');
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const yyyy = d.getFullYear();
      return `${dd}-${mm}-${yyyy}`;
    }
    return "";
  });
  const [endDateChanged, setEndDateChanged] = useState(!!discount.endDate);

  const handleStartDateChange = useCallback((v: string) => {
    setStartDate(v);
    if (v) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.startDate;
        return next;
      });
    }
    if (!endDateChanged && v) {
      // Parse DD-MM-YYYY
      const parts = v.split('-');
      if (parts.length === 3) {
        const d = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`);
        if (!isNaN(d.getTime())) {
          d.setMonth(d.getMonth() + 1);
          const dd = String(d.getDate()).padStart(2, '0');
          const mm = String(d.getMonth() + 1).padStart(2, '0');
          const yyyy = d.getFullYear();
          setEndDate(`${dd}-${mm}-${yyyy}`);
        }
      }
    }
  }, [endDateChanged]);

  const handleEndDateChange = useCallback((v: string) => {
    setEndDate(v);
    setEndDateChanged(true);
    if (v) {
      setErrors((prev: any) => {
        const next = { ...prev };
        delete next.endDate;
        return next;
      });
    }
  }, []);

  return (
    <Frame>
      <Page title="Edit Discount" backAction={{ content: "Discount Codes", onAction: onCancel }}>
      <Layout>
        {errors.general && <Layout.Section><Banner tone="critical" title="Error"><p>{errors.general}</p></Banner></Layout.Section>}
        <Layout.Section>
          <Form method="post">
            <input type="hidden" name="intent" value="edit" />
            <input type="hidden" name="id" value={discount.id} />
            <BlockStack gap="500">
              <Card>
                <BlockStack gap="400">
                  <InlineStack align="space-between">
                    <Text as="h2" variant="headingMd">Discount Details</Text>
                    <Badge tone="info">{discount.discountCode}</Badge>
                  </InlineStack>
                  <FormLayout>
                    <TextField label="Name" name="title" value={title} onChange={handleTitleChange} error={errors.title} autoComplete="off" />
                  </FormLayout>
                </BlockStack>
              </Card>
              <Card>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingMd">Threshold Status</Text>
                  <InlineGrid columns={{ xs: 1, sm: 3 }} gap="400">
                    <Box padding="400" background="bg-surface-secondary" borderRadius="200">
                      <BlockStack gap="100">
                        <Text as="p" variant="bodySm" tone="subdued">Total Budget</Text>
                        <Text as="p" variant="headingLg">{formatCurrency(discount.totalThreshold, currencyCode)}</Text>
                      </BlockStack>
                    </Box>
                    <Box padding="400" background="bg-surface-secondary" borderRadius="200">
                      <BlockStack gap="100">
                        <Text as="p" variant="bodySm" tone="subdued">Used</Text>
                        <Text as="p" variant="headingLg">{formatCurrency(discount.usedAmount, currencyCode)}</Text>
                      </BlockStack>
                    </Box>
                    <Box padding="400" background={discount.remainingAmount > 0 ? "bg-surface-success" : "bg-surface-critical"} borderRadius="200">
                      <BlockStack gap="100">
                        <Text as="p" variant="bodySm" tone="subdued">Remaining</Text>
                        <Text as="p" variant="headingLg" tone={discount.remainingAmount > 0 ? "success" : "critical"}>
                          {formatCurrency(discount.remainingAmount, currencyCode)}
                        </Text>
                      </BlockStack>
                    </Box>
                  </InlineGrid>
                  <Divider />
                  <FormLayout>
                    <Select label="Discount Type" name="discountType" options={[{ label: "Percentage", value: "percentage" }, { label: "Fixed Amount", value: "fixed" }]} value={discountType} onChange={setDiscountType} />
                    <Select label="Discount Category" name="discountCategory" options={DISCOUNT_CATEGORIES} value={discountCategory} onChange={setDiscountCategory} />
                    <Select
                      label="Payment Method (Optional)"
                      name="paymentType"
                      options={[
                        { label: "-- No restriction --", value: "" },
                        { label: "Credit Card", value: "Credit Card" },
                        { label: "Net 10", value: "Net 10" },
                        { label: "Net 30", value: "Net 30" },
                        { label: "Net 31", value: "Net 31" },
                        { label: "Net 60", value: "Net 60" },
                        { label: "Net 180", value: "Net 180" },
                        { label: "1% 10, Net 30", value: "1% 10, Net 30" },
                        { label: "1% 15, Net 30", value: "1% 15, Net 30" },
                        { label: "2% 15, Net 30", value: "2% 15, Net 30" },
                        { label: "2% 30, Net 31", value: "2% 30, Net 31" },
                        { label: "2% 31, Net 31", value: "2% 31, Net 31" },
                      ]}
                      value={paymentType}
                      onChange={setPaymentType}
                      helpText="If selected, restricts checkout to this payment method"
                    />

                    <FormLayout.Group>
                      {discountType === "percentage" ? (
                        <TextField label="Discount Percentage" name="percentage" value={percentage} onChange={handlePercentageChange} suffix="%" type="number" error={errors.percentage} autoComplete="off" />
                      ) : (() => {
                        const fixedNum = parseFloat(fixedValue);
                        const threshNum = parseFloat(threshold);
                        const fixedClientError = (!isNaN(fixedNum) && !isNaN(threshNum) && fixedNum > threshNum)
                          ? "Fixed discount amount cannot be greater than the total threshold budget"
                          : errors.fixedValue;
                        return <TextField label="Fixed Discount Amount" name="fixedValue" value={fixedValue} onChange={handleFixedValueChange} prefix={getCurrencySymbol(currencyCode)} type="number" helpText="Flat deduction from subtotal" error={fixedClientError} autoComplete="off" />;
                      })()}
                      <TextField label="Total Threshold Budget" name="threshold" value={threshold} onChange={handleThresholdChange} prefix={getCurrencySymbol(currencyCode)} type="number" helpText={`Must be at least ${formatCurrency(discount.usedAmount, currencyCode)} (already used)`} error={errors.threshold} autoComplete="off" />
                    </FormLayout.Group>
                    <FormLayout.Group>
                      <DateSelectionPicker label="Start Date" dateStr={startDate} onChange={handleStartDateChange} error={errors.startDate} />
                      <DateSelectionPicker label="End Date" dateStr={endDate} onChange={handleEndDateChange} helpText="Clear exactly to remove end date" error={errors.endDate} />
                    </FormLayout.Group>
                  </FormLayout>
                </BlockStack>
              </Card>
              <Card>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingMd">Free Product Mapping</Text>
                  {specialProducts.map((row) => (
                    <InlineStack key={row.id} gap="300" blockAlign="start">
                      <Box minWidth="300px">
                        <TextField
                          label="Product"
                          value={row.productTitle}
                          onChange={() => { }}
                          autoComplete="off"
                          connectedRight={<Button onClick={() => handleProductSelect(row.id)}>Browse</Button>}
                          error={errors[`specialProduct_${row.id}`]}
                        />
                      </Box>
                      <Box minWidth="100px">
                        <TextField
                          label="Quantity"
                          type="number"
                          value={row.quantity !== undefined ? String(row.quantity) : "1"}
                          onChange={(v) => handleQuantityChange(row.id, v)}
                          autoComplete="off"
                          min={1}
                        />
                      </Box>
                      <Box minWidth="250px">
                        <Select
                          label="Discount Category"
                          options={DISCOUNT_CATEGORIES}
                          value={row.category}
                          onChange={(v) => handleCategoryChange(row.id, v)}
                        />
                      </Box>
                      <div style={{ marginTop: "24px" }}>
                        <Button tone="critical" onClick={() => handleRemoveProductRow(row.id)}>Remove</Button>
                      </div>
                    </InlineStack>
                  ))}
                  <InlineStack>
                    <Button onClick={handleAddProductRow}>Add Product Row</Button>
                  </InlineStack>
                </BlockStack>
                <input type="hidden" name="specialProducts" value={JSON.stringify(specialProducts)} />
              </Card>
              <Divider />
              <InlineStack gap="300" align="end">
                <Button onClick={onCancel}>Cancel</Button>
                <Button variant="primary" submit loading={isSubmitting}>Save Changes</Button>
              </InlineStack>
            </BlockStack>
          </Form>
        </Layout.Section>
      </Layout>
      {toastActive && <Toast content={toastMessage} onDismiss={() => setToastActive(false)} />}
    </Page>
    </Frame>
  );
}
